import { useState } from "react";

export default function GymTracker() {
  const exercises = {
    "Upper (Push)": ["Bench Press", "Overhead Shoulder Press", "Incline Dumbbell Press", "Lateral Raises", "Triceps Dips"],
    "Lower Body": ["Squats", "Romanian Deadlifts", "Leg Press", "Bulgarian Split Squats", "Seated Calf Raises"],
    "HIIT": ["Battle Ropes", "Kettlebell Swings", "Rowing Machine Sprints", "Box Jumps", "Sled Push"],
    "Upper (Pull)": ["Deadlifts", "Pull-Ups", "Bent-Over Rows", "Face Pulls", "Bicep Curls"],
    "Lower Body 2": ["Deadlifts (Romanian)", "Hip Thrusts", "Leg Curls", "Lunges", "Standing Calf Raises"]
  };

  const [data, setData] = useState({});

  const handleChange = (exercise, field, value) => {
    setData((prev) => ({
      ...prev,
      [exercise]: { ...prev[exercise], [field]: value }
    }));
  };

  return (
    <div className="p-4">
      {Object.entries(exercises).map(([category, exerciseList]) => (
        <div key={category} className="mb-6 border p-4 rounded-md shadow-md">
          <h2 className="text-xl font-bold mb-2">{category}</h2>
          <table className="table-auto w-full">
            <thead>
              <tr>
                <th className="px-4 py-2">Exercise</th>
                <th className="px-4 py-2">Weight (kg)</th>
                <th className="px-4 py-2">Reps</th>
                <th className="px-4 py-2">Sets</th>
              </tr>
            </thead>
            <tbody>
              {exerciseList.map((exercise) => (
                <tr key={exercise}>
                  <td className="border px-4 py-2">{exercise}</td>
                  <td className="border px-4 py-2">
                    <input
                      type="number"
                      value={data[exercise]?.weight || ""}
                      onChange={(e) => handleChange(exercise, "weight", e.target.value)}
                      className="border p-1 w-full"
                    />
                  </td>
                  <td className="border px-4 py-2">
                    <input
                      type="number"
                      value={data[exercise]?.reps || ""}
                      onChange={(e) => handleChange(exercise, "reps", e.target.value)}
                      className="border p-1 w-full"
                    />
                  </td>
                  <td className="border px-4 py-2">
                    <input
                      type="number"
                      value={data[exercise]?.sets || ""}
                      onChange={(e) => handleChange(exercise, "sets", e.target.value)}
                      className="border p-1 w-full"
                    />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ))}
      <button className="mt-4 p-2 bg-blue-500 text-white rounded">Save Progress</button>
    </div>
  );
}