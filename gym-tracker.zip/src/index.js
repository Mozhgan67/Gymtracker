import React from "react";
import ReactDOM from "react-dom";
import GymTracker from "./App";

ReactDOM.render(<GymTracker />, document.getElementById("root"));